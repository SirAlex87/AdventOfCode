package service;

import org.apache.logging.log4j.Level;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ServiceTest6 {

	private static final Logger logger = LogManager.getLogger(ServiceTest6.class);
	private int contatore=0;
	private String [][] arrayFinal = null;
	List<Integer> listaPosizioniDelimitatori= new ArrayList<>();
	
	public void populateArray(String s) {
		String []a = s.split("-");
		IntStream.rangeClosed(0, a.length-1).forEach(j->
			arrayFinal[contatore][j]=a[j]
		);
		contatore++;
	}

	public void initilizeArray(String[] strParts) {
		arrayFinal= new String[strParts.length][strParts[0].split("-").length];
		
	}

	@Override
	public String toString() {
		return "ServiceTest6 [arrayFinal=" + Arrays.toString(arrayFinal) + "]";
	}

	public BigInteger calculate() {
		BigInteger contoFinale = BigInteger.ZERO;

		int numColumns = arrayFinal[0].length;

		for (int x = 0; x < numColumns; x++) { // scorre le righe
			BigInteger contoParziale = BigInteger.ZERO;
			for (int j = arrayFinal.length - 2; j >= 0; j--) {
				if (arrayFinal[arrayFinal.length - 1][x].equals("+")) {
					contoParziale = contoParziale.add(new BigInteger(arrayFinal[j][x]));
				}
				if (arrayFinal[arrayFinal.length - 1][x].equals("*")) {
					if (contoParziale.equals(BigInteger.ZERO)){
						contoParziale=BigInteger.ONE;
					}
					contoParziale = contoParziale.multiply(new BigInteger(arrayFinal[j][x]));
				}
			}
			contoFinale=contoFinale.add(contoParziale);
		}



		return contoFinale;
	}
	
	public BigInteger calculate2() {
		BigInteger contoFinale = BigInteger.ZERO;

		int numColumns = arrayFinal[0].length;
		for (int i = 0; i < numColumns; i++) {// colonne
			BigInteger contoParziale = BigInteger.ZERO;
				if (arrayFinal[arrayFinal.length - 1][i].trim().equals("+")) {
					contoParziale = manageCharacterPlus(i, contoParziale);
				}
				if (arrayFinal[arrayFinal.length - 1][i].trim().equals("*")) {
					contoParziale = manageCharacterAsterisk(i, contoParziale);
				}
			contoFinale = contoFinale.add(contoParziale);
		}

		return contoFinale;
	}

	private BigInteger manageCharacterAsterisk(int i, BigInteger contoParziale) {
		int limite;
		if (contoParziale.equals(BigInteger.ZERO)) {
			contoParziale = BigInteger.ONE;
		}
		limite=arrayFinal[0][i].length();

		for (int k = 0; k < limite; k++) {
			StringBuilder result = new StringBuilder();
			String xFinale = "";
			for (int x = 0; x <= arrayFinal.length - 2; x++) {// righe
				logger.log(Level.DEBUG,"X:{0} Limite:{1} k:{2} i:{3} j:{4}",x,limite,k,i,0);
				String xTemp = arrayFinal[x][i].substring(limite - k-1,
						limite -k);
				if (xTemp.isBlank()) {
					xTemp = "";
				}
				xFinale=result.append(xTemp).toString();
			}
			contoParziale = contoParziale.multiply(new BigInteger(xFinale));
		}
		return contoParziale;
	}

	private BigInteger manageCharacterPlus(int i, BigInteger contoParziale) {
		int limite;
		limite=arrayFinal[0][i].length();
		for (int k = 0; k < limite; k++) {
			StringBuilder result = new StringBuilder();
			String xFinale = "";
			for (int x = 0; x <= arrayFinal.length - 2; x++) {// righe
				logger.log(Level.DEBUG,"X:{0} Limite:{1} k:{2} i:{3} j:{4}",x,limite,k,i,0);
				String xTemp = arrayFinal[x][i].substring(limite - k-1,
						limite -k);
				if (xTemp.isBlank()) {
					xTemp = "";
				}
				xFinale=result.append(xTemp).toString();
			}
			contoParziale = contoParziale.add(new BigInteger(xFinale));
		}
		return contoParziale;
	}

	public void populateSecondArray(String[] strParts) {
		String [] strParts2 = new String [strParts.length];
		int j=0;
		for(String s:strParts) {
			for(int x=0;x<listaPosizioniDelimitatori.size();x++) {
				s=s.substring(0, listaPosizioniDelimitatori.get(x)-1)+"-"+s.substring(listaPosizioniDelimitatori.get(x));
			}
			strParts2[j]=s;
			j++;
		}
		this.initilizeArray(strParts2);
		Arrays.stream(strParts2).forEach(this::populateArray);
		
	}

	public void findDelimitator(String s) {		
		int plus=1;
		int multiply=1;
		int firstPos=0;
		while(plus>=0 || multiply>=0) {
			plus=s.indexOf('+',firstPos);
			if(plus==0) {
				plus=s.indexOf('+',1);
			}
			multiply=s.indexOf('*',firstPos);
			if(multiply==0) {
				multiply=s.indexOf('+',1);
			}
			if(plus>0 && multiply>0)
				firstPos = Math.min(plus, multiply);
			else if(plus>0) {
				firstPos=plus;
			}
			else if(multiply>0) {
				firstPos=multiply;
			}
			else {
				firstPos=0;
			}
			if(firstPos>0) {
				listaPosizioniDelimitatori.add(firstPos);
				firstPos++;
			}
		}
	}

	public void printArray() {

		for (int x = 0; x < arrayFinal.length; x++) { // scorre le righe
			for (int j = 0; j < arrayFinal[x].length; j++) { // scorre le colonne
				logger.log(Level.DEBUG, "{} ",arrayFinal[x][j]);
			}
			logger.debug("\n");
		}		
	}
	
}
